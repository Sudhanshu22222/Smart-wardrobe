// ─── Simple localStorage database ─────────────────────────
// No backend, no MongoDB, no Cloudinary needed.
// All data saved in browser localStorage as JSON.

const KEY_USER    = 'oa_user';
const KEY_CLOTHES = 'oa_clothes';
const KEY_OUTFITS = 'oa_outfits';

// helpers
const load = (key, fallback = null) => {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
};
const save = (key, val) => localStorage.setItem(key, JSON.stringify(val));
const uid  = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

// ─── Auth ──────────────────────────────────────────────────
export const authStore = {
  getUser: () => load(KEY_USER),
  login: (email, password) => {
    const user = load(KEY_USER);
    if (!user) throw new Error('No account found. Please register first.');
    if (user.email !== email) throw new Error('Email not found.');
    if (user.password !== btoa(password)) throw new Error('Wrong password.');
    return user;
  },
  register: (name, email, password) => {
    const existing = load(KEY_USER);
    if (existing && existing.email === email) throw new Error('Email already registered.');
    const user = { id: uid(), name, email, password: btoa(password), createdAt: new Date().toISOString() };
    save(KEY_USER, user);
    return user;
  },
  updateUser: (updates) => {
    const user = load(KEY_USER);
    const updated = { ...user, ...updates };
    save(KEY_USER, updated);
    return updated;
  },
  changePassword: (current, next) => {
    const user = load(KEY_USER);
    if (user.password !== btoa(current)) throw new Error('Current password is wrong.');
    save(KEY_USER, { ...user, password: btoa(next) });
  },
};

// ─── Clothes ───────────────────────────────────────────────
export const clothesStore = {
  getAll: (filters = {}) => {
    let items = load(KEY_CLOTHES, []);
    if (filters.category && filters.category !== 'all') items = items.filter(i => i.category === filters.category);
    if (filters.style    && filters.style    !== 'all') items = items.filter(i => i.style    === filters.style);
    if (filters.search)  items = items.filter(i => i.name.toLowerCase().includes(filters.search.toLowerCase()));
    return items.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  add: (item) => {
    const items = load(KEY_CLOTHES, []);
    const newItem = { ...item, id: uid(), createdAt: new Date().toISOString() };
    save(KEY_CLOTHES, [newItem, ...items]);
    return newItem;
  },
  update: (id, updates) => {
    const items = load(KEY_CLOTHES, []);
    const next  = items.map(i => i.id === id ? { ...i, ...updates } : i);
    save(KEY_CLOTHES, next);
    return next.find(i => i.id === id);
  },
  delete: (id) => {
    const items = load(KEY_CLOTHES, []);
    save(KEY_CLOTHES, items.filter(i => i.id !== id));
  },
  getStats: () => {
    const items = load(KEY_CLOTHES, []);
    const byCategory = {};
    items.forEach(i => { byCategory[i.category] = (byCategory[i.category] || 0) + 1; });
    return { total: items.length, byCategory };
  },
};

// ─── Saved Outfits ─────────────────────────────────────────
export const outfitStore = {
  getAll: () => load(KEY_OUTFITS, []).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)),
  save: (outfit) => {
    const all  = load(KEY_OUTFITS, []);
    const newO = { ...outfit, id: uid(), createdAt: new Date().toISOString() };
    save(KEY_OUTFITS, [newO, ...all]);
    return newO;
  },
  delete: (id) => {
    save(KEY_OUTFITS, load(KEY_OUTFITS, []).filter(o => o.id !== id));
  },
};

// ─── AI: Color Analysis ────────────────────────────────────
// Runs entirely in browser using <canvas> — no Python needed
export const analyzeImageColor = (file) => new Promise((resolve) => {
  const img = new Image();
  const url = URL.createObjectURL(file);
  img.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 50; canvas.height = 50;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, 50, 50);
    const data = ctx.getImageData(0, 0, 50, 50).data;
    let r = 0, g = 0, b = 0, count = 0;
    for (let i = 0; i < data.length; i += 4) {
      // skip near-white background pixels
      if (data[i] > 240 && data[i+1] > 240 && data[i+2] > 240) continue;
      r += data[i]; g += data[i+1]; b += data[i+2]; count++;
    }
    URL.revokeObjectURL(url);
    if (count === 0) { resolve({ color: 'white', colorHex: '#ffffff' }); return; }
    r = Math.round(r/count); g = Math.round(g/count); b = Math.round(b/count);
    const hex = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
    resolve({ color: nearestColorName(r,g,b), colorHex: hex });
  };
  img.src = url;
});

const COLOR_MAP = [
  ['black',   0,   0,   0  ], ['white',   255, 255, 255],
  ['grey',    128, 128, 128], ['red',     220, 50,  50 ],
  ['blue',    50,  100, 200], ['navy',    20,  40,  100],
  ['green',   50,  180, 50 ], ['yellow',  255, 220, 0  ],
  ['orange',  255, 140, 0  ], ['purple',  150, 50,  200],
  ['pink',    255, 150, 200], ['brown',   139, 90,  43 ],
  ['beige',   210, 190, 150], ['maroon',  128, 0,   0  ],
  ['teal',    0,   128, 128], ['coral',   255, 120, 90 ],
  ['olive',   128, 128, 0  ], ['indigo',  75,  0,   130],
  ['gold',    212, 175, 55 ], ['charcoal',54,  69,  79 ],
  ['lavender',230, 190, 255], ['cream',   255, 250, 220],
];
function nearestColorName(r, g, b) {
  let min = Infinity, name = 'black';
  for (const [n, cr, cg, cb] of COLOR_MAP) {
    const d = Math.hypot(r-cr, g-cg, b-cb);
    if (d < min) { min = d; name = n; }
  }
  return name;
}

// ─── AI: Outfit Generator ──────────────────────────────────
const OCCASION_STYLES = {
  casual:    ['casual','streetwear','bohemian'],
  college:   ['casual','streetwear','smart-casual'],
  interview: ['formal','classic','smart-casual'],
  date:      ['smart-casual','casual','classic'],
  party:     ['streetwear','smart-casual','casual'],
  gym:       ['sporty'],
  travel:    ['casual','sporty','streetwear'],
  work:      ['formal','classic','smart-casual'],
};
const WEATHER_SEASONS = {
  hot:    ['summer','all-season'],
  cold:   ['winter','all-season','autumn'],
  rainy:  ['rainy','all-season'],
  normal: ['all-season','spring','summer','autumn'],
};
const WEATHER_BLOCK = {
  hot:   ['jacket','coat','hoodie','boots'],
  cold:  ['shorts','sandals'],
  rainy: ['sandals'],
};
const COLOR_FAMILIES = {
  neutral: ['black','white','grey','gray','beige','cream','ivory','charcoal','navy','brown'],
  warm:    ['red','orange','yellow','maroon','coral','salmon','rust','gold','brown'],
  cool:    ['blue','green','purple','teal','mint','cyan','indigo','violet','olive'],
  pastel:  ['pink','lavender','lilac','peach','cream','gold'],
};
function colorFamily(color) {
  const c = color.toLowerCase();
  for (const [fam, colors] of Object.entries(COLOR_FAMILIES))
    if (colors.some(x => c.includes(x))) return fam;
  return 'other';
}

export function generateOutfits(wardrobe, occasion, weather) {
  const tops    = wardrobe.filter(i => i.category === 'topwear');
  const bottoms = wardrobe.filter(i => i.category === 'bottomwear');
  const shoes   = wardrobe.filter(i => i.category === 'footwear');
  const outers  = wardrobe.filter(i => i.category === 'outerwear');
  const blocked = WEATHER_BLOCK[weather] || [];

  const combos = [];
  for (const top of tops) {
    for (const bot of bottoms) {
      for (const shoe of shoes) {
        if ([top,bot,shoe].some(i => blocked.includes(i.type))) continue;
        combos.push([top,bot,shoe]);
        for (const out of outers) {
          if (blocked.includes(out.type)) continue;
          combos.push([top,bot,shoe,out]);
        }
      }
    }
  }

  const validStyles  = OCCASION_STYLES[occasion] || ['casual'];
  const validSeasons = WEATHER_SEASONS[weather]  || ['all-season'];

  const scored = combos.map(items => {
    let score = 0; const reasons = [];
    // Color
    const fams = items.map(i => colorFamily(i.color));
    const neutrals = fams.filter(f => f === 'neutral').length;
    const unique   = new Set(fams.filter(f => f !== 'neutral')).size;
    if (neutrals >= items.length - 1 || unique <= 1) { score += 5; reasons.push('Colors complement each other'); }
    else if (unique === 2) score += 3;
    // Style
    const styleMatch = items.every(i => validStyles.includes(i.style));
    if (styleMatch) { score += 5; reasons.push(`Perfect ${occasion} style`); }
    else if (items.some(i => validStyles.includes(i.style))) score += 2;
    // Occasion
    score += 10; reasons.push('Top & bottom combination');
    // Season
    const seasonOk = items.every(i => validSeasons.includes(i.season) || i.season === 'all-season');
    if (seasonOk) { score += 5; reasons.push(`Great for ${weather} weather`); }
    // Footwear
    score += 5; reasons.push('Complete with footwear');
    // Normalize
    const pct = Math.min(Math.round((score / 30) * 100), 98);
    return { items, score: pct, reasons };
  });

  return scored.sort((a,b) => b.score - a.score).slice(0, 3);
}
