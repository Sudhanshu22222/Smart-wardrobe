import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { RiDashboardLine, RiUploadCloud2Line, RiShirtLine,
         RiMagicLine, RiBookmarkLine, RiUserLine,
         RiMenuLine, RiCloseLine, RiSparklingLine } from 'react-icons/ri';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const NAV = [
  { to: '/dashboard', Icon: RiDashboardLine,    label: 'Dashboard' },
  { to: '/upload',    Icon: RiUploadCloud2Line,  label: 'Upload Clothes' },
  { to: '/wardrobe',  Icon: RiShirtLine,         label: 'My Wardrobe' },
  { to: '/generate',  Icon: RiMagicLine,         label: 'Generate Outfit' },
  { to: '/saved',     Icon: RiBookmarkLine,      label: 'Saved Looks' },
  { to: '/profile',   Icon: RiUserLine,          label: 'Profile' },
];

function Sidebar({ onClose }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const initial = user?.name?.[0]?.toUpperCase() || 'U';

  const handleLogout = () => { logout(); toast.success('Logged out'); navigate('/login'); };

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100%', background:'var(--bg2)', borderRight:'1px solid var(--border)' }}>
      {/* Logo */}
      <div style={{ padding:'20px 18px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:10 }}>
        <div style={{ width:34, height:34, borderRadius:10, background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
          <RiSparklingLine style={{ color:'#fff', fontSize:18 }} />
        </div>
        <div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontWeight:700, fontSize:16, color:'var(--text)' }}>OutfitAI</div>
          <div style={{ fontSize:10, color:'var(--text3)' }}>Smart Wardrobe</div>
        </div>
        {onClose && (
          <button onClick={onClose} style={{ marginLeft:'auto', background:'none', color:'var(--text3)', fontSize:20 }}>
            <RiCloseLine />
          </button>
        )}
      </div>

      {/* Nav */}
      <nav style={{ flex:1, padding:'12px 10px', display:'flex', flexDirection:'column', gap:2 }}>
        {NAV.map(({ to, Icon, label }) => (
          <NavLink key={to} to={to} onClick={onClose}
            style={({ isActive }) => ({
              display:'flex', alignItems:'center', gap:10,
              padding:'10px 12px', borderRadius:10,
              fontSize:14, fontWeight:500,
              color: isActive ? 'var(--brand)' : 'var(--text3)',
              background: isActive ? 'var(--brand-dim)' : 'transparent',
              transition:'all 0.15s',
              textDecoration:'none',
            })}
          >
            <Icon style={{ fontSize:19, flexShrink:0 }} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* User */}
      <div style={{ padding:'12px 14px', borderTop:'1px solid var(--border)', display:'flex', alignItems:'center', gap:10 }}>
        <div style={{ width:32, height:32, borderRadius:9, background:'rgba(236,72,153,0.2)', border:'1px solid rgba(236,72,153,0.3)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--brand)', fontWeight:700, fontSize:13, flexShrink:0 }}>
          {initial}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:13, fontWeight:500, color:'var(--text)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{user?.name}</div>
          <div style={{ fontSize:11, color:'var(--text3)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{user?.email}</div>
        </div>
      </div>
    </div>
  );
}

export default function AppLayout() {
  const [open, setOpen] = useState(false);

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'var(--bg)' }}>
      {/* Desktop sidebar */}
      <div style={{ width:220, flexShrink:0, display:'none' }} className="desk-sidebar">
        <div style={{ position:'fixed', top:0, left:0, width:220, height:'100vh', zIndex:10 }}>
          <Sidebar />
        </div>
      </div>

      {/* Mobile overlay */}
      {open && (
        <div style={{ position:'fixed', inset:0, zIndex:50, display:'flex' }}>
          <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.7)' }} onClick={() => setOpen(false)} />
          <div style={{ position:'relative', zIndex:51, width:240 }}>
            <Sidebar onClose={() => setOpen(false)} />
          </div>
        </div>
      )}

      {/* Content */}
      <div style={{ flex:1, display:'flex', flexDirection:'column' }}>
        {/* Mobile topbar */}
        <div className="mobile-bar" style={{ display:'flex', alignItems:'center', gap:10, padding:'12px 16px', borderBottom:'1px solid var(--border)', background:'var(--bg2)' }}>
          <button onClick={() => setOpen(true)} style={{ background:'none', color:'var(--text2)', fontSize:22 }}>
            <RiMenuLine />
          </button>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:26, height:26, borderRadius:8, background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <RiSparklingLine style={{ color:'#fff', fontSize:14 }} />
            </div>
            <span style={{ fontFamily:"'Playfair Display',serif", fontWeight:700, fontSize:16, color:'var(--text)' }}>OutfitAI</span>
          </div>
        </div>

        <main style={{ flex:1, overflow:'auto' }}>
          <Outlet />
        </main>
      </div>

      <style>{`
        @media(min-width:768px){
          .desk-sidebar{display:block !important;}
          .mobile-bar{display:none !important;}
          main > *{margin-left:0;}
        }
        @media(max-width:767px){
          .page{padding:20px 16px !important;}
        }
      `}</style>
    </div>
  );
}
