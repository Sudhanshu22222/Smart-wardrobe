import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { RiSparklingLine, RiEyeLine, RiEyeOffLine } from 'react-icons/ri';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const [form, setForm]           = useState({ email:'', password:'' });
  const [showPw, setShowPw]       = useState(false);
  const [loading, setLoading]     = useState(false);
  const { login }                 = useAuth();
  const navigate                  = useNavigate();

  const onChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const onSubmit = async e => {
    e.preventDefault();
    if (!form.email || !form.password) { toast.error('Fill in all fields'); return; }
    setLoading(true);
    try {
      login(form.email, form.password);
      toast.success('Welcome back! 👗');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message);
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', display:'flex', alignItems:'center', justifyContent:'center', padding:24 }}>
      <div style={{ width:'100%', maxWidth:400 }}>
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <Link to="/" style={{ display:'inline-flex', alignItems:'center', gap:8, marginBottom:20 }}>
            <div style={{ width:36, height:36, borderRadius:11, background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <RiSparklingLine style={{ color:'#fff', fontSize:18 }} />
            </div>
            <span style={{ fontFamily:"'Playfair Display',serif", fontWeight:700, fontSize:20, color:'var(--text)' }}>OutfitAI</span>
          </Link>
          <h1 style={{ fontFamily:"'Playfair Display',serif", fontSize:28, fontWeight:700, color:'var(--text)', marginBottom:6 }}>Welcome back</h1>
          <p style={{ color:'var(--text3)', fontSize:14 }}>Sign in to your wardrobe</p>
        </div>

        <div className="card">
          <form onSubmit={onSubmit}>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input name="email" type="email" value={form.email} onChange={onChange}
                className="input" placeholder="you@example.com" />
            </div>
            <div className="form-group" style={{ position:'relative' }}>
              <label className="form-label">Password</label>
              <input name="password" type={showPw ? 'text' : 'password'} value={form.password} onChange={onChange}
                className="input" placeholder="••••••••" style={{ paddingRight:42 }} />
              <button type="button" onClick={() => setShowPw(v => !v)}
                style={{ position:'absolute', right:12, bottom:11, background:'none', color:'var(--text3)', fontSize:18, lineHeight:1 }}>
                {showPw ? <RiEyeOffLine /> : <RiEyeLine />}
              </button>
            </div>
            <button type="submit" disabled={loading} className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'12px', marginTop:6 }}>
              {loading ? <div className="spinner" /> : 'Sign In'}
            </button>
          </form>
        </div>

        <p style={{ textAlign:'center', color:'var(--text3)', fontSize:13, marginTop:20 }}>
          Don't have an account?{' '}
          <Link to="/register" style={{ color:'var(--brand)', fontWeight:500 }}>Create one →</Link>
        </p>
      </div>
    </div>
  );
}
