import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { RiSparklingLine } from 'react-icons/ri';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Register() {
  const [form, setForm]       = useState({ name:'', email:'', password:'', confirm:'' });
  const [loading, setLoading] = useState(false);
  const { register }          = useAuth();
  const navigate              = useNavigate();

  const onChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const onSubmit = e => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password) { toast.error('Fill in all fields'); return; }
    if (form.password.length < 6) { toast.error('Password min 6 characters'); return; }
    if (form.password !== form.confirm) { toast.error('Passwords do not match'); return; }
    setLoading(true);
    try {
      register(form.name, form.email, form.password);
      toast.success('Account created! 🎉');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message);
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', display:'flex', alignItems:'center', justifyContent:'center', padding:24 }}>
      <div style={{ width:'100%', maxWidth:400 }}>
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <Link to="/" style={{ display:'inline-flex', alignItems:'center', gap:8, marginBottom:20 }}>
            <div style={{ width:36, height:36, borderRadius:11, background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <RiSparklingLine style={{ color:'#fff', fontSize:18 }} />
            </div>
            <span style={{ fontFamily:"'Playfair Display',serif", fontWeight:700, fontSize:20, color:'var(--text)' }}>OutfitAI</span>
          </Link>
          <h1 style={{ fontFamily:"'Playfair Display',serif", fontSize:28, fontWeight:700, color:'var(--text)', marginBottom:6 }}>Create your account</h1>
          <p style={{ color:'var(--text3)', fontSize:14 }}>Start building your digital wardrobe</p>
        </div>

        <div className="card">
          <form onSubmit={onSubmit}>
            {[
              ['Full Name','name','text','Alex Fashion'],
              ['Email','email','email','you@example.com'],
              ['Password','password','password','Min. 6 characters'],
              ['Confirm Password','confirm','password','Repeat password'],
            ].map(([label, name, type, placeholder]) => (
              <div className="form-group" key={name}>
                <label className="form-label">{label}</label>
                <input name={name} type={type} value={form[name]} onChange={onChange}
                  className="input" placeholder={placeholder} />
              </div>
            ))}
            <button type="submit" disabled={loading} className="btn btn-primary"
              style={{ width:'100%', justifyContent:'center', padding:'12px', marginTop:6 }}>
              {loading ? <div className="spinner" /> : 'Create Account'}
            </button>
          </form>
        </div>

        <p style={{ textAlign:'center', color:'var(--text3)', fontSize:13, marginTop:20 }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color:'var(--brand)', fontWeight:500 }}>Sign in →</Link>
        </p>
      </div>
    </div>
  );
}
