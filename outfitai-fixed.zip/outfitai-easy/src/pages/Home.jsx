import React from 'react';
import { Link } from 'react-router-dom';
import { RiSparklingLine, RiArrowRightLine, RiShirtLine, RiMagicLine, RiBookmarkLine } from 'react-icons/ri';

const features = [
  { icon: RiShirtLine,    title: 'Digital Wardrobe',     desc: 'Upload photos of your clothes. Stored privately in your browser — no account needed.', color:'#ec4899' },
  { icon: RiMagicLine,    title: 'AI Outfit Generator',  desc: 'Pick your occasion and weather. Get top 3 curated outfit combinations from your wardrobe.', color:'#a78bfa' },
  { icon: RiBookmarkLine, title: 'Save Your Looks',      desc: 'Bookmark your favorite outfits and revisit them anytime with style scores and match reasons.', color:'#34d399' },
];

export default function Home() {
  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', overflowX:'hidden' }}>

      {/* Nav */}
      <nav style={{ position:'sticky', top:0, zIndex:40, background:'rgba(10,11,13,0.85)', backdropFilter:'blur(12px)', borderBottom:'1px solid var(--border)', padding:'14px 32px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:32, height:32, borderRadius:10, background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <RiSparklingLine style={{ color:'#fff', fontSize:17 }} />
          </div>
          <span style={{ fontFamily:"'Playfair Display',serif", fontWeight:700, fontSize:18, color:'var(--text)' }}>OutfitAI</span>
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <Link to="/login" className="btn btn-outline" style={{ padding:'8px 18px', fontSize:13 }}>Sign In</Link>
          <Link to="/register" className="btn btn-primary" style={{ padding:'8px 18px', fontSize:13 }}>Get Started</Link>
        </div>
      </nav>

      {/* Hero */}
      <section style={{ position:'relative', minHeight:'88vh', display:'flex', alignItems:'center', justifyContent:'center', textAlign:'center', padding:'60px 24px', overflow:'hidden' }}>
        {/* bg blobs */}
        <div style={{ position:'absolute', top:'20%', left:'20%', width:380, height:380, background:'rgba(236,72,153,0.07)', borderRadius:'50%', filter:'blur(80px)', pointerEvents:'none' }} />
        <div style={{ position:'absolute', bottom:'20%', right:'15%', width:300, height:300, background:'rgba(167,139,250,0.07)', borderRadius:'50%', filter:'blur(80px)', pointerEvents:'none' }} />
        {/* grid */}
        <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(255,255,255,0.015) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.015) 1px,transparent 1px)', backgroundSize:'60px 60px', pointerEvents:'none' }} />

        <div style={{ position:'relative', zIndex:2, maxWidth:680 }} className="animate-in">
          <div style={{ display:'inline-flex', alignItems:'center', gap:8, background:'rgba(236,72,153,0.1)', border:'1px solid rgba(236,72,153,0.25)', borderRadius:100, padding:'6px 16px', fontSize:13, color:'var(--brand)', marginBottom:28 }}>
            <RiSparklingLine /> AI-Powered Smart Wardrobe
          </div>

          <h1 style={{ fontFamily:"'Playfair Display',serif", fontSize:'clamp(40px,7vw,76px)', fontWeight:700, color:'var(--text)', lineHeight:1.1, marginBottom:20 }}>
            Dress <span className="gradient-text" style={{ fontStyle:'italic' }}>smarter</span><br />every day
          </h1>

          <p style={{ fontSize:'clamp(15px,2.5vw,19px)', color:'var(--text3)', lineHeight:1.6, marginBottom:36, maxWidth:520, margin:'0 auto 36px' }}>
            Upload your clothes, get AI-curated outfit combinations matched to your occasion and weather — all running locally in your browser.
          </p>

          <div style={{ display:'flex', gap:12, justifyContent:'center', flexWrap:'wrap' }}>
            <Link to="/register" className="btn btn-primary" style={{ padding:'13px 30px', fontSize:15 }}>
              Start Building Your Wardrobe <RiArrowRightLine />
            </Link>
            <Link to="/login" className="btn btn-outline" style={{ padding:'13px 24px', fontSize:15 }}>
              Sign In
            </Link>
          </div>

          <div style={{ display:'flex', gap:36, justifyContent:'center', marginTop:48 }}>
            {[['100%','Browser-based'],['0 setup','No backend needed'],['Private','Data stays on device']].map(([v,l]) => (
              <div key={l} style={{ textAlign:'center' }}>
                <div className="gradient-text" style={{ fontSize:20, fontWeight:700, fontFamily:"'Playfair Display',serif" }}>{v}</div>
                <div style={{ fontSize:12, color:'var(--text3)', marginTop:2 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding:'80px 32px', maxWidth:960, margin:'0 auto' }}>
        <div style={{ textAlign:'center', marginBottom:48 }}>
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:'clamp(28px,5vw,44px)', fontWeight:700, color:'var(--text)', marginBottom:10 }}>
            Everything in one place
          </h2>
          <p style={{ color:'var(--text3)', fontSize:16 }}>No cloud. No accounts required beyond a local profile. Just open and go.</p>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:18 }}>
          {features.map(({ icon: Icon, title, desc, color }) => (
            <div key={title} className="card" style={{ position:'relative', overflow:'hidden' }}>
              <div style={{ width:44, height:44, borderRadius:13, background:`${color}22`, border:`1px solid ${color}44`, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:16 }}>
                <Icon style={{ fontSize:22, color }} />
              </div>
              <h3 style={{ fontFamily:"'Playfair Display',serif", fontSize:18, fontWeight:600, color:'var(--text)', marginBottom:8 }}>{title}</h3>
              <p style={{ fontSize:14, color:'var(--text3)', lineHeight:1.65 }}>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding:'60px 32px 80px', textAlign:'center' }}>
        <div style={{ maxWidth:540, margin:'0 auto', background:'rgba(236,72,153,0.06)', border:'1px solid rgba(236,72,153,0.18)', borderRadius:24, padding:'48px 32px' }}>
          <RiSparklingLine style={{ fontSize:36, color:'var(--brand)', marginBottom:16 }} />
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:32, fontWeight:700, color:'var(--text)', marginBottom:10 }}>Ready to get styled?</h2>
          <p style={{ color:'var(--text3)', marginBottom:28, fontSize:15 }}>Create your free account and start building your digital wardrobe in minutes.</p>
          <Link to="/register" className="btn btn-primary" style={{ padding:'13px 30px', fontSize:15, margin:'0 auto' }}>
            Create Free Account <RiArrowRightLine />
          </Link>
        </div>
      </section>

      <footer style={{ borderTop:'1px solid var(--border)', padding:'20px 32px', textAlign:'center', color:'var(--text3)', fontSize:13 }}>
        OutfitAI © {new Date().getFullYear()} — Data stored locally in your browser
      </footer>
    </div>
  );
}
