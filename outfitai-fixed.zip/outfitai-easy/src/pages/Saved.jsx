import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { RiMagicLine, RiDeleteBinLine, RiCalendarLine, RiSparklingLine } from 'react-icons/ri';
import { outfitStore } from '../utils/store';
import toast from 'react-hot-toast';

export default function Saved() {
  const [outfits, setOutfits]   = useState([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    setOutfits(outfitStore.getAll());
    setLoading(false);
  }, []);

  const handleDelete = (id) => {
    if (!window.confirm('Remove this saved look?')) return;
    outfitStore.delete(id);
    setOutfits(prev => prev.filter(o => o.id !== id));
    toast.success('Look removed');
  };

  const scoreColor = s => s >= 75 ? { bg:'rgba(236,72,153,0.15)', col:'#f472b6' }
                        : s >= 50 ? { bg:'rgba(251,191,36,0.15)',  col:'#fbbf24' }
                        :           { bg:'rgba(255,255,255,0.06)',  col:'#6c757d' };

  return (
    <div className="page">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
        <div>
          <h1 className="page-title">Saved Looks</h1>
          <p className="page-sub" style={{ marginBottom:0 }}>{outfits.length} outfit{outfits.length !== 1 ? 's' : ''} saved</p>
        </div>
        <Link to="/generate" className="btn btn-primary" style={{ flexShrink:0 }}>
          <RiMagicLine /> Generate New
        </Link>
      </div>

      <div style={{ marginTop:24 }}>
        {loading ? (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:14 }}>
            {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height:220 }} />)}
          </div>
        ) : outfits.length === 0 ? (
          <div className="card" style={{ textAlign:'center', padding:'64px 20px' }}>
            <div style={{ fontSize:52, marginBottom:14 }}>🧥</div>
            <div style={{ fontFamily:"'Playfair Display',serif", fontSize:20, color:'var(--text)', marginBottom:8 }}>No saved looks yet</div>
            <p style={{ color:'var(--text3)', fontSize:14, marginBottom:20 }}>Generate outfit combinations and save your favorites here.</p>
            <Link to="/generate" className="btn btn-primary" style={{ margin:'0 auto' }}>
              <RiMagicLine /> Generate Outfits
            </Link>
          </div>
        ) : (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:14 }}>
            {outfits.map(outfit => {
              const items = outfit.items || [];
              const sc    = scoreColor(outfit.score);
              const slots = [
                items.find(i => i.category === 'topwear'),
                items.find(i => i.category === 'bottomwear'),
                items.find(i => i.category === 'footwear'),
                items.find(i => i.category === 'outerwear'),
              ];

              return (
                <div key={outfit.id} className="card" style={{ padding:0, overflow:'hidden', position:'relative' }}
                  onMouseEnter={e => e.currentTarget.querySelector('.del-btn').style.opacity='1'}
                  onMouseLeave={e => e.currentTarget.querySelector('.del-btn').style.opacity='0'}>

                  {/* Delete button */}
                  <button className="del-btn" onClick={() => handleDelete(outfit.id)}
                    style={{ position:'absolute', top:8, right:8, zIndex:2, width:28, height:28, borderRadius:'50%', background:'rgba(0,0,0,0.7)', border:'none', color:'#f87171', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15, cursor:'pointer', opacity:0, transition:'opacity 0.2s' }}>
                    <RiDeleteBinLine />
                  </button>

                  {/* Preview grid */}
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gridTemplateRows:'1fr 1fr', aspectRatio:'1', padding:8, gap:4, background:'var(--bg3)' }}>
                    {slots.map((item, i) => item ? (
                      <div key={i} style={{ borderRadius:7, overflow:'hidden', background:'var(--bg4)' }}>
                        <img src={item.imageData} alt="" style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                      </div>
                    ) : (
                      <div key={i} style={{ borderRadius:7, border:'1px dashed rgba(255,255,255,0.08)' }} />
                    ))}
                  </div>

                  {/* Info */}
                  <div style={{ padding:'12px 14px 14px' }}>
                    <div style={{ fontFamily:"'Playfair Display',serif", fontSize:14, fontWeight:600, color:'var(--text)', marginBottom:6, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
                      {outfit.name || `${outfit.occasion} look`}
                    </div>
                    <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:8 }}>
                      <span className="badge" style={{ background:sc.bg, color:sc.col, display:'flex', alignItems:'center', gap:4 }}>
                        <RiSparklingLine style={{ fontSize:9 }} /> {outfit.score}% match
                      </span>
                      {outfit.occasion && (
                        <span className="badge" style={{ background:'rgba(255,255,255,0.06)', color:'var(--text3)', textTransform:'capitalize' }}>{outfit.occasion}</span>
                      )}
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:5, color:'var(--text3)', fontSize:11 }}>
                      <RiCalendarLine />
                      {new Date(outfit.createdAt).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
                    </div>
                    {outfit.reasons?.[0] && (
                      <div style={{ marginTop:8, paddingTop:8, borderTop:'1px solid var(--border)', fontSize:11, color:'var(--text3)' }}>
                        {outfit.reasons[0]}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
