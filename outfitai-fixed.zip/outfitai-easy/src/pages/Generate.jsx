import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { RiMagicLine, RiBookmarkLine, RiArrowRightLine,
         RiSparklingLine, RiSunLine, RiTempColdLine, RiUmbrellaLine, RiWindyLine } from 'react-icons/ri';
import { clothesStore, outfitStore, generateOutfits } from '../utils/store';
import toast from 'react-hot-toast';

const OCCASIONS = [
  { v:'casual',    label:'Casual',    emoji:'😎' },
  { v:'college',   label:'College',   emoji:'🎒' },
  { v:'interview', label:'Interview', emoji:'💼' },
  { v:'date',      label:'Date Night',emoji:'🌹' },
  { v:'party',     label:'Party',     emoji:'🎉' },
  { v:'gym',       label:'Gym',       emoji:'💪' },
  { v:'travel',    label:'Travel',    emoji:'✈️' },
  { v:'work',      label:'Work',      emoji:'🏢' },
];
const WEATHERS = [
  { v:'hot',    label:'Hot',    Icon: RiSunLine,       color:'#fb923c' },
  { v:'cold',   label:'Cold',   Icon: RiTempColdLine,  color:'#60a5fa' },
  { v:'rainy',  label:'Rainy',  Icon: RiUmbrellaLine,  color:'#34d399' },
  { v:'normal', label:'Normal', Icon: RiWindyLine,     color:'#a78bfa' },
];

function ScoreRing({ score }) {
  const r   = 22, circ = 2 * Math.PI * r;
  const off = circ - (score / 100) * circ;
  const col = score >= 75 ? '#ec4899' : score >= 50 ? '#f59e0b' : '#6b7280';
  return (
    <svg width="60" height="60" viewBox="0 0 60 60" style={{ flexShrink:0 }}>
      <circle cx="30" cy="30" r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="4" />
      <circle cx="30" cy="30" r={r} fill="none" stroke={col} strokeWidth="4"
        strokeDasharray={circ} strokeDashoffset={off} strokeLinecap="round"
        style={{ transform:'rotate(-90deg)', transformOrigin:'50% 50%', transition:'stroke-dashoffset 1s ease' }} />
      <text x="30" y="34" textAnchor="middle" fill="#f1f3f5" fontSize="13" fontWeight="600">{score}</text>
    </svg>
  );
}

function OutfitCard({ outfit, index, onSave }) {
  const [saved, setSaved] = useState(false);
  const slots = [
    { label:'Top',     item: outfit.items.find(i => i.category === 'topwear') },
    { label:'Bottom',  item: outfit.items.find(i => i.category === 'bottomwear') },
    { label:'Footwear',item: outfit.items.find(i => i.category === 'footwear') },
    { label:'Layer',   item: outfit.items.find(i => i.category === 'outerwear') },
  ];

  const handleSave = () => {
    onSave(outfit);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="card animate-in" style={{ animationDelay:`${index*0.1}s`, marginBottom:14 }}>
      <div style={{ display:'flex', alignItems:'flex-start', gap:14, marginBottom:16 }}>
        <ScoreRing score={outfit.score} />
        <div style={{ flex:1 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
            <span style={{ fontFamily:"'Playfair Display',serif", fontSize:16, fontWeight:600, color:'var(--text)' }}>Outfit #{index + 1}</span>
            {index === 0 && (
              <span className="badge" style={{ background:'rgba(236,72,153,0.15)', color:'#f472b6', display:'flex', alignItems:'center', gap:4 }}>
                <RiSparklingLine style={{ fontSize:10 }} /> Best Match
              </span>
            )}
          </div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:5 }}>
            {outfit.reasons.map((r, i) => (
              <span key={i} style={{ fontSize:11, color:'var(--text3)', background:'rgba(255,255,255,0.04)', border:'1px solid var(--border)', padding:'2px 8px', borderRadius:20 }}>
                ✓ {r}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Item slots */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:14 }}>
        {slots.map(({ label, item }) => (
          <div key={label} style={{ borderRadius:10, overflow:'hidden', border:'1px solid var(--border)', background:'var(--bg3)' }}>
            {item ? (
              <>
                <div style={{ aspectRatio:'1', overflow:'hidden' }}>
                  <img src={item.imageData} alt={item.type} style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                </div>
                <div style={{ padding:'5px 7px' }}>
                  <div style={{ fontSize:10.5, color:'var(--text)', fontWeight:500, textTransform:'capitalize', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{item.name || item.type}</div>
                  <div style={{ fontSize:10, color:'var(--text3)', textTransform:'capitalize' }}>{item.color}</div>
                </div>
              </>
            ) : (
              <div style={{ aspectRatio:'1', display:'flex', alignItems:'center', justifyContent:'center', borderStyle:'dashed', border:'1px dashed rgba(255,255,255,0.1)', borderRadius:9, background:'transparent' }}>
                <span style={{ fontSize:10, color:'var(--text3)', textAlign:'center', padding:4 }}>{label}<br/>—</span>
              </div>
            )}
          </div>
        ))}
      </div>

      <button onClick={handleSave}
        style={{
          width:'100%', padding:'9px', borderRadius:10,
          background: saved ? 'rgba(52,211,153,0.12)' : 'transparent',
          border: `1px solid ${saved ? 'rgba(52,211,153,0.3)' : 'var(--border)'}`,
          color: saved ? '#34d399' : 'var(--text2)',
          display:'flex', alignItems:'center', justifyContent:'center', gap:7,
          fontSize:13, fontWeight:500, cursor:'pointer', transition:'all 0.2s',
        }}>
        <RiBookmarkLine />
        {saved ? 'Saved! ✓' : 'Save This Look'}
      </button>
    </div>
  );
}

export default function Generate() {
  const [occ,     setOcc]     = useState('casual');
  const [wx,      setWx]      = useState('normal');
  const [outfits, setOutfits] = useState([]);
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  const handleGenerate = () => {
    setLoading(true);
    setOutfits([]);
    setTimeout(() => {
      const wardrobe = clothesStore.getAll();
      if (wardrobe.length < 2) {
        toast.error('Add more clothes to your wardrobe first!');
        setLoading(false);
        return;
      }
      const results = generateOutfits(wardrobe, occ, wx);
      setOutfits(results);
      setGenerated(true);
      if (results.length === 0) toast('No combinations found — try different settings', { icon:'🤔' });
      setLoading(false);
    }, 800); // small delay for UX
  };

  const handleSave = (outfit) => {
    outfitStore.save({
      items: outfit.items,
      score: outfit.score,
      reasons: outfit.reasons,
      occasion: occ,
      weather: wx,
      name: `${occ.charAt(0).toUpperCase()+occ.slice(1)} Look`,
    });
    toast.success('Look saved! 🎉');
  };

  const selBtn = (active) => ({
    border: `1px solid ${active ? 'rgba(236,72,153,0.5)' : 'var(--border)'}`,
    background: active ? 'rgba(236,72,153,0.12)' : 'rgba(255,255,255,0.03)',
    cursor:'pointer', transition:'all 0.15s', borderRadius:12,
  });

  return (
    <div className="page">
      <h1 className="page-title">Generate Outfit</h1>
      <p className="page-sub">Choose your occasion and weather — AI will build the best looks from your wardrobe.</p>

      <div className="card" style={{ marginBottom:20 }}>
        {/* Occasion */}
        <div style={{ fontSize:13, fontWeight:600, color:'var(--text2)', marginBottom:10, textTransform:'uppercase', letterSpacing:'0.5px' }}>Occasion</div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:20 }}>
          {OCCASIONS.map(({ v, label, emoji }) => (
            <button key={v} onClick={() => { setOcc(v); setGenerated(false); }} style={{ ...selBtn(occ===v), padding:'10px 4px', textAlign:'center' }}>
              <div style={{ fontSize:20, marginBottom:4 }}>{emoji}</div>
              <div style={{ fontSize:11.5, color: occ===v ? 'var(--brand)' : 'var(--text3)', fontWeight:500 }}>{label}</div>
            </button>
          ))}
        </div>

        {/* Weather */}
        <div style={{ fontSize:13, fontWeight:600, color:'var(--text2)', marginBottom:10, textTransform:'uppercase', letterSpacing:'0.5px' }}>Weather</div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:20 }}>
          {WEATHERS.map(({ v, label, Icon, color }) => (
            <button key={v} onClick={() => { setWx(v); setGenerated(false); }} style={{ ...selBtn(wx===v), padding:'12px 8px', display:'flex', alignItems:'center', gap:8 }}>
              <Icon style={{ fontSize:18, color: wx===v ? 'var(--brand)' : color, flexShrink:0 }} />
              <span style={{ fontSize:12.5, color: wx===v ? 'var(--brand)' : 'var(--text3)', fontWeight:500 }}>{label}</span>
            </button>
          ))}
        </div>

        <button onClick={handleGenerate} disabled={loading} className="btn btn-primary"
          style={{ width:'100%', justifyContent:'center', padding:'13px', fontSize:15 }}>
          {loading
            ? <><div className="spinner" /> Generating...</>
            : <><RiMagicLine /> Generate My Outfits <RiArrowRightLine /></>}
        </button>
      </div>

      {/* Results */}
      {outfits.length > 0 && (
        <div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:22, fontWeight:600, color:'var(--text)', marginBottom:16, display:'flex', alignItems:'center', gap:10 }}>
            <RiSparklingLine style={{ color:'var(--brand)' }} />
            Top {outfits.length} Combinations
            <span style={{ fontSize:14, color:'var(--text3)', fontFamily:'DM Sans,sans-serif', fontWeight:400 }}>for {occ} in {wx} weather</span>
          </div>
          {outfits.map((o, i) => <OutfitCard key={i} outfit={o} index={i} onSave={handleSave} />)}
        </div>
      )}

      {/* Empty state */}
      {!loading && generated && outfits.length === 0 && (
        <div className="card" style={{ textAlign:'center', padding:'48px 20px' }}>
          <div style={{ fontSize:48, marginBottom:12 }}>🤷</div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:18, color:'var(--text)', marginBottom:8 }}>No outfits found</div>
          <p style={{ color:'var(--text3)', fontSize:14, marginBottom:18 }}>Try different occasion/weather, or add more clothes with a mix of tops, bottoms, and footwear.</p>
          <Link to="/upload" className="btn btn-primary" style={{ margin:'0 auto' }}>Add More Clothes</Link>
        </div>
      )}

      {!generated && (
        <div className="card" style={{ textAlign:'center', padding:'48px 20px' }}>
          <div style={{ fontSize:48, marginBottom:12 }}>✨</div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:18, color:'var(--text)', marginBottom:8 }}>Ready to generate</div>
          <p style={{ color:'var(--text3)', fontSize:13 }}>
            Pick your occasion and weather above, then hit Generate.<br />
            Make sure you have clothes in your <Link to="/wardrobe" style={{ color:'var(--brand)' }}>wardrobe</Link> first.
          </p>
        </div>
      )}
    </div>
  );
}
