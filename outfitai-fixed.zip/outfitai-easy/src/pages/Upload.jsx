import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { RiUploadCloud2Line, RiCloseLine, RiSparklingLine, RiCheckLine } from 'react-icons/ri';
import { clothesStore, analyzeImageColor } from '../utils/store';
import toast from 'react-hot-toast';

const TYPES    = ['t-shirt','shirt','jeans','trouser','shorts','dress','skirt','jacket','coat','hoodie','shoes','sneakers','boots','sandals','other'];
const PATTERNS = ['plain','striped','checked','printed','floral','other'];
const STYLES   = ['casual','formal','sporty','streetwear','bohemian','classic','smart-casual'];
const SEASONS  = ['all-season','summer','winter','rainy','spring','autumn'];

function getCategoryFromType(type) {
  if (['shirt','t-shirt','hoodie','dress'].includes(type))      return 'topwear';
  if (['jeans','trouser','shorts','skirt'].includes(type))      return 'bottomwear';
  if (['shoes','sneakers','boots','sandals'].includes(type))    return 'footwear';
  if (['jacket','coat'].includes(type))                         return 'outerwear';
  return 'accessory';
}

export default function Upload() {
  const navigate = useNavigate();
  const [file,      setFile]      = useState(null);
  const [preview,   setPreview]   = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed,  setAnalyzed]  = useState(false);
  const [saving,    setSaving]    = useState(false);
  const [dragging,  setDragging]  = useState(false);
  const [form, setForm] = useState({
    name:'', type:'shirt', color:'black', colorHex:'#000000',
    pattern:'plain', style:'casual', season:'all-season',
  });

  const handleFile = useCallback(async (f) => {
    if (!f || !f.type.startsWith('image/')) { toast.error('Please select an image file'); return; }
    if (f.size > 8 * 1024 * 1024) { toast.error('Image must be under 8MB'); return; }
    setFile(f);
    const reader = new FileReader();
    reader.onload = e => setPreview(e.target.result);
    reader.readAsDataURL(f);
    // AI color analysis
    setAnalyzing(true);
    try {
      const { color, colorHex } = await analyzeImageColor(f);
      setForm(prev => ({ ...prev, color, colorHex }));
      setAnalyzed(true);
      toast.success('Color detected by AI ✨');
    } catch { /* silently fallback */ }
    finally { setAnalyzing(false); }
  }, []);

  const onDrop = e => {
    e.preventDefault(); setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const onFileInput = e => handleFile(e.target.files[0]);
  const onChange    = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const onSubmit = async e => {
    e.preventDefault();
    if (!file) { toast.error('Please select an image first'); return; }
    setSaving(true);
    try {
      // Convert to base64 for localStorage
      const reader = new FileReader();
      reader.onload = ev => {
        clothesStore.add({
          ...form,
          category: getCategoryFromType(form.type),
          imageData: ev.target.result,
        });
        toast.success('Added to wardrobe! 🎉');
        navigate('/wardrobe');
      };
      reader.readAsDataURL(file);
    } catch { toast.error('Failed to save'); setSaving(false); }
  };

  const reset = () => { setFile(null); setPreview(null); setAnalyzed(false); };

  const inputStyle = { display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 };

  return (
    <div className="page">
      <h1 className="page-title">Upload Clothing</h1>
      <p className="page-sub">Add a new item to your wardrobe. AI will detect the dominant color automatically.</p>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:24 }}>

        {/* Drop zone */}
        <div>
          {!preview ? (
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              onClick={() => document.getElementById('file-input').click()}
              style={{
                border: `2px dashed ${dragging ? 'var(--brand)' : 'rgba(255,255,255,0.15)'}`,
                borderRadius: 18, minHeight: 280,
                display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                cursor:'pointer', transition:'all 0.2s',
                background: dragging ? 'rgba(236,72,153,0.06)' : 'rgba(255,255,255,0.02)',
                padding: 32, textAlign:'center',
              }}
            >
              <div style={{ width:56, height:56, borderRadius:16, background:'rgba(236,72,153,0.1)', border:'1px solid rgba(236,72,153,0.25)', display:'flex', alignItems:'center', justifyContent:'center', marginBottom:16 }}>
                <RiUploadCloud2Line style={{ fontSize:28, color:'var(--brand)' }} />
              </div>
              <div style={{ fontSize:16, fontWeight:500, color:'var(--text)', marginBottom:6 }}>
                {dragging ? 'Drop it here!' : 'Drop your photo here'}
              </div>
              <div style={{ fontSize:13, color:'var(--text3)', marginBottom:6 }}>or click to browse</div>
              <div style={{ fontSize:12, color:'var(--text3)' }}>JPG · PNG · WEBP up to 8MB</div>
              <input id="file-input" type="file" accept="image/*" onChange={onFileInput} style={{ display:'none' }} />
            </div>
          ) : (
            <div style={{ position:'relative', borderRadius:18, overflow:'hidden', border:'1px solid var(--border)', background:'var(--bg3)' }}>
              <img src={preview} alt="Preview" style={{ width:'100%', maxHeight:320, objectFit:'contain', display:'block' }} />
              <button onClick={reset}
                style={{ position:'absolute', top:10, right:10, width:32, height:32, borderRadius:'50%', background:'rgba(0,0,0,0.6)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18 }}>
                <RiCloseLine />
              </button>
              {analyzing && (
                <div style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.6)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:12 }}>
                  <div className="spinner" />
                  <div style={{ color:'#fff', display:'flex', alignItems:'center', gap:8, fontSize:14 }}>
                    <RiSparklingLine style={{ color:'var(--brand)' }} /> Analysing color...
                  </div>
                </div>
              )}
              {analyzed && !analyzing && (
                <div style={{ position:'absolute', top:10, left:10 }}>
                  <span className="badge" style={{ background:'rgba(52,211,153,0.2)', color:'#34d399', display:'flex', alignItems:'center', gap:5 }}>
                    <RiCheckLine /> AI color detected
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Form */}
        <form onSubmit={onSubmit}>
          <div className="form-group">
            <label className="form-label">Item Name (optional)</label>
            <input name="name" value={form.name} onChange={onChange} className="input" placeholder="e.g. Blue Oxford Shirt" />
          </div>

          <div style={inputStyle}>
            <div className="form-group">
              <label className="form-label">Type</label>
              <select name="type" value={form.type} onChange={onChange} className="input">
                {TYPES.map(t => <option key={t} value={t} style={{ background:'#1e2026', textTransform:'capitalize' }}>{t}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Pattern</label>
              <select name="pattern" value={form.pattern} onChange={onChange} className="input">
                {PATTERNS.map(p => <option key={p} value={p} style={{ background:'#1e2026', textTransform:'capitalize' }}>{p}</option>)}
              </select>
            </div>
          </div>

          <div style={inputStyle}>
            <div className="form-group">
              <label className="form-label">Style</label>
              <select name="style" value={form.style} onChange={onChange} className="input">
                {STYLES.map(s => <option key={s} value={s} style={{ background:'#1e2026', textTransform:'capitalize' }}>{s}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Season</label>
              <select name="season" value={form.season} onChange={onChange} className="input">
                {SEASONS.map(s => <option key={s} value={s} style={{ background:'#1e2026', textTransform:'capitalize' }}>{s}</option>)}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Color</label>
            <div style={{ display:'flex', gap:10 }}>
              <input name="color" value={form.color} onChange={onChange} className="input" placeholder="e.g. navy blue" style={{ flex:1 }} />
              <input type="color" name="colorHex" value={form.colorHex} onChange={onChange}
                style={{ width:46, height:42, borderRadius:10, border:'1px solid var(--border)', background:'var(--bg3)', cursor:'pointer', padding:3 }} />
            </div>
          </div>

          <button type="submit" disabled={!file || saving || analyzing} className="btn btn-primary"
            style={{ width:'100%', justifyContent:'center', padding:'13px', marginTop:4 }}>
            {saving ? <div className="spinner" /> : <><RiUploadCloud2Line /> Add to Wardrobe</>}
          </button>
        </form>
      </div>
    </div>
  );
}
