import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { RiShirtLine, RiBookmarkLine, RiMagicLine,
         RiUploadCloud2Line, RiArrowRightLine } from 'react-icons/ri';
import { clothesStore, outfitStore } from '../utils/store';
import { useAuth } from '../context/AuthContext';

const CAT_COLOR = { topwear:'#ec4899', bottomwear:'#a78bfa', footwear:'#fbbf24', outerwear:'#34d399' };

export default function Dashboard() {
  const { user }                = useAuth();
  const [stats, setStats]       = useState({ total:0, byCategory:{} });
  const [recent, setRecent]     = useState([]);
  const [savedCt, setSavedCt]   = useState(0);

  useEffect(() => {
    setStats(clothesStore.getStats());
    setRecent(clothesStore.getAll().slice(0, 6));
    setSavedCt(outfitStore.getAll().length);
  }, []);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const first = user?.name?.split(' ')[0] || 'there';

  return (
    <div className="page">
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:28 }}>
        <div>
          <div style={{ fontSize:12, color:'var(--text3)', marginBottom:4 }}>
            {new Date().toLocaleDateString('en-US', { weekday:'long', month:'long', day:'numeric' })}
          </div>
          <h1 style={{ fontFamily:"'Playfair Display',serif", fontSize:'clamp(22px,4vw,32px)', fontWeight:700, color:'var(--text)' }}>
            {greeting}, <span className="gradient-text">{first}</span> ✨
          </h1>
          <p style={{ color:'var(--text3)', fontSize:14, marginTop:4 }}>Ready to look amazing today?</p>
        </div>
        <Link to="/generate" className="btn btn-primary" style={{ display:'none', flexShrink:0 }} id="gen-btn">
          <RiMagicLine /> Generate Outfit
        </Link>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(130px,1fr))', gap:12, marginBottom:28 }}>
        {[
          { icon:RiShirtLine,    label:'Total Clothes',  val: stats.total,                          color:'#ec4899' },
          { icon:RiBookmarkLine, label:'Saved Outfits',  val: savedCt,                              color:'#a78bfa' },
          { icon:RiShirtLine,    label:'Topwear',        val: stats.byCategory.topwear    || 0,     color:'#fb923c' },
          { icon:RiShirtLine,    label:'Footwear',       val: stats.byCategory.footwear   || 0,     color:'#34d399' },
        ].map(({ icon:Icon, label, val, color }) => (
          <div key={label} className="card" style={{ display:'flex', alignItems:'center', gap:12, padding:16 }}>
            <div style={{ width:40, height:40, borderRadius:11, background:`${color}22`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <Icon style={{ color, fontSize:20 }} />
            </div>
            <div>
              <div style={{ fontFamily:"'Playfair Display',serif", fontSize:24, fontWeight:700, color:'var(--text)', lineHeight:1 }}>{val}</div>
              <div style={{ fontSize:12, color:'var(--text3)', marginTop:3 }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent wardrobe */}
      <div style={{ marginBottom:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:13, fontWeight:600, color:'var(--text2)', textTransform:'uppercase', letterSpacing:'0.5px' }}>Recent Wardrobe</span>
        <Link to="/wardrobe" style={{ fontSize:13, color:'var(--brand)', display:'flex', alignItems:'center', gap:4 }}>View all <RiArrowRightLine /></Link>
      </div>

      {recent.length === 0 ? (
        <div className="card" style={{ textAlign:'center', padding:'48px 20px' }}>
          <div style={{ fontSize:52, marginBottom:14 }}>👗</div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:18, color:'var(--text)', marginBottom:8 }}>Your wardrobe is empty</div>
          <p style={{ color:'var(--text3)', fontSize:14, marginBottom:20 }}>Upload your first clothing item to get started</p>
          <Link to="/upload" className="btn btn-primary" style={{ margin:'0 auto' }}>
            <RiUploadCloud2Line /> Upload Clothes
          </Link>
        </div>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(130px,1fr))', gap:10 }}>
          {recent.map(item => (
            <Link to="/wardrobe" key={item.id} style={{ textDecoration:'none' }}>
              <div style={{ borderRadius:14, overflow:'hidden', border:'1px solid var(--border)', background:'var(--bg3)', transition:'transform 0.2s' }}
                onMouseEnter={e => e.currentTarget.style.transform='translateY(-3px)'}
                onMouseLeave={e => e.currentTarget.style.transform='translateY(0)'}>
                <div style={{ aspectRatio:'1', overflow:'hidden', background:'var(--bg4)' }}>
                  <img src={item.imageData} alt={item.name || item.type}
                    style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                </div>
                <div style={{ padding:'8px 10px' }}>
                  <div style={{ fontSize:12, fontWeight:500, color:'var(--text)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', textTransform:'capitalize' }}>{item.name || item.type}</div>
                  <div style={{ fontSize:11, color:'var(--text3)', marginTop:2, textTransform:'capitalize' }}>{item.color} · {item.style}</div>
                  <span className="badge" style={{ background: `${CAT_COLOR[item.category] || '#888'}22`, color: CAT_COLOR[item.category] || '#888', marginTop:5, fontSize:10 }}>
                    {item.category}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* Mobile generate btn */}
      {stats.total > 0 && (
        <div style={{ marginTop:20 }}>
          <Link to="/generate" className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:13 }}>
            <RiMagicLine /> Generate Today's Outfit
          </Link>
        </div>
      )}
    </div>
  );
}
