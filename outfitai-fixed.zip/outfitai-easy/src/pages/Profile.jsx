import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { RiUserLine, RiLockLine, RiLogoutBoxLine, RiCheckLine, RiDeleteBin2Line } from 'react-icons/ri';
import { useAuth } from '../context/AuthContext';
import { authStore, clothesStore, outfitStore } from '../utils/store';
import toast from 'react-hot-toast';

export default function Profile() {
  const { user, updateUser, logout } = useAuth();
  const navigate = useNavigate();

  const [name,    setName]    = useState(user?.name || '');
  const [savingN, setSavingN] = useState(false);

  const [pwForm,  setPwForm]  = useState({ current:'', next:'', confirm:'' });
  const [savingP, setSavingP] = useState(false);

  const saveName = () => {
    if (!name.trim()) { toast.error('Name cannot be empty'); return; }
    setSavingN(true);
    updateUser({ name: name.trim() });
    toast.success('Name updated');
    setSavingN(false);
  };

  const savePassword = () => {
    if (!pwForm.current || !pwForm.next) { toast.error('Fill all fields'); return; }
    if (pwForm.next.length < 6) { toast.error('Password min 6 characters'); return; }
    if (pwForm.next !== pwForm.confirm) { toast.error('Passwords do not match'); return; }
    setSavingP(true);
    try {
      authStore.changePassword(pwForm.current, pwForm.next);
      toast.success('Password changed!');
      setPwForm({ current:'', next:'', confirm:'' });
    } catch (err) {
      toast.error(err.message);
    } finally { setSavingP(false); }
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out');
    navigate('/login');
  };

  const clearAllData = () => {
    if (!window.confirm('This will delete ALL your clothes and saved outfits. Are you sure?')) return;
    localStorage.removeItem('oa_clothes');
    localStorage.removeItem('oa_outfits');
    toast.success('All wardrobe data cleared');
  };

  const secStyle = { marginBottom: 14 };
  const hStyle = {
    display:'flex', alignItems:'center', gap:9,
    fontFamily:"'Playfair Display',serif", fontSize:16, fontWeight:600, color:'var(--text)', marginBottom:14,
  };

  return (
    <div className="page" style={{ maxWidth:480 }}>
      <h1 className="page-title">Profile Settings</h1>
      <p className="page-sub">Manage your account and data</p>

      {/* Avatar card */}
      <div className="card" style={{ display:'flex', alignItems:'center', gap:16, marginBottom:14 }}>
        <div style={{ width:52, height:52, borderRadius:14, background:'rgba(236,72,153,0.2)', border:'1px solid rgba(236,72,153,0.3)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:"'Playfair Display',serif", fontSize:24, fontWeight:700, color:'var(--brand)', flexShrink:0 }}>
          {user?.name?.[0]?.toUpperCase()}
        </div>
        <div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:18, fontWeight:600, color:'var(--text)' }}>{user?.name}</div>
          <div style={{ fontSize:13, color:'var(--text3)' }}>{user?.email}</div>
          <div style={{ fontSize:11, color:'var(--text3)', marginTop:2 }}>
            Member since {new Date(user?.createdAt || Date.now()).toLocaleDateString('en-US', { month:'long', year:'numeric' })}
          </div>
        </div>
      </div>

      {/* Display name */}
      <div className="card" style={secStyle}>
        <div style={hStyle}><RiUserLine style={{ color:'var(--brand)', fontSize:18 }} /> Display Name</div>
        <div style={{ display:'flex', gap:10 }}>
          <input value={name} onChange={e => setName(e.target.value)} className="input" style={{ flex:1 }} placeholder="Your name" />
          <button onClick={saveName} disabled={savingN} className="btn btn-primary" style={{ padding:'10px 14px' }}>
            {savingN ? <div className="spinner" style={{ width:16,height:16 }} /> : <RiCheckLine />}
          </button>
        </div>
      </div>

      {/* Change password */}
      <div className="card" style={secStyle}>
        <div style={hStyle}><RiLockLine style={{ color:'#fb923c', fontSize:18 }} /> Change Password</div>
        {[
          ['Current Password', 'current'],
          ['New Password',     'next'],
          ['Confirm New Password', 'confirm'],
        ].map(([label, key]) => (
          <div className="form-group" key={key}>
            <label className="form-label">{label}</label>
            <input type="password" value={pwForm[key]}
              onChange={e => setPwForm(f => ({ ...f, [key]: e.target.value }))}
              className="input" placeholder="••••••••" />
          </div>
        ))}
        <button onClick={savePassword} disabled={savingP} className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'11px' }}>
          {savingP ? <div className="spinner" /> : <><RiLockLine /> Update Password</>}
        </button>
      </div>

      {/* Data */}
      <div className="card" style={secStyle}>
        <div style={hStyle}><RiDeleteBin2Line style={{ color:'#f87171', fontSize:18 }} /> Data & Storage</div>
        <p style={{ fontSize:13, color:'var(--text3)', marginBottom:14, lineHeight:1.6 }}>
          All your clothes and saved outfits are stored locally in your browser. Clearing will permanently remove all wardrobe data.
        </p>
        <button onClick={clearAllData}
          style={{ padding:'9px 18px', borderRadius:10, background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.25)', color:'#f87171', fontSize:13, fontWeight:500, cursor:'pointer', display:'flex', alignItems:'center', gap:7 }}>
          <RiDeleteBin2Line /> Clear All Wardrobe Data
        </button>
      </div>

      {/* Logout */}
      <div className="card" style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ fontSize:14, fontWeight:500, color:'var(--text)' }}>Sign Out</div>
          <div style={{ fontSize:12, color:'var(--text3)' }}>You'll need to sign back in</div>
        </div>
        <button onClick={handleLogout}
          style={{ padding:'9px 16px', borderRadius:10, background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.25)', color:'#f87171', fontSize:13, fontWeight:500, cursor:'pointer', display:'flex', alignItems:'center', gap:7 }}>
          <RiLogoutBoxLine /> Logout
        </button>
      </div>
    </div>
  );
}
