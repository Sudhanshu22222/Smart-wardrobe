import React, { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { RiUploadCloud2Line, RiSearchLine, RiEditLine, RiDeleteBinLine, RiCloseLine, RiCheckLine } from 'react-icons/ri';
import { clothesStore } from '../utils/store';
import toast from 'react-hot-toast';

const CAT_STYLE = {
  topwear:    { bg:'rgba(236,72,153,0.15)',  color:'#f472b6' },
  bottomwear: { bg:'rgba(167,139,250,0.15)', color:'#a78bfa' },
  footwear:   { bg:'rgba(251,191,36,0.15)',  color:'#fbbf24' },
  outerwear:  { bg:'rgba(52,211,153,0.15)',  color:'#34d399' },
  accessory:  { bg:'rgba(156,163,175,0.15)', color:'#9ca3af' },
};
const STYLES  = ['casual','formal','sporty','streetwear','bohemian','classic','smart-casual'];
const SEASONS = ['all-season','summer','winter','rainy','spring','autumn'];

function EditModal({ item, onClose, onSave }) {
  const [form, setForm] = useState({ name:item.name, color:item.color, colorHex:item.colorHex, style:item.style, season:item.season });
  const [saving, setSaving] = useState(false);
  const onChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const save = async () => {
    setSaving(true);
    onSave(item.id, form);
    onClose();
  };

  return (
    <div style={{ position:'fixed', inset:0, zIndex:60, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}>
      <div style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.75)', backdropFilter:'blur(4px)' }} onClick={onClose} />
      <div className="card" style={{ position:'relative', zIndex:1, width:'100%', maxWidth:380, padding:24 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
          <span style={{ fontFamily:"'Playfair Display',serif", fontSize:18, fontWeight:600, color:'var(--text)' }}>Edit Item</span>
          <button onClick={onClose} style={{ background:'none', color:'var(--text3)', fontSize:20 }}><RiCloseLine /></button>
        </div>
        <div className="form-group">
          <label className="form-label">Name</label>
          <input name="name" value={form.name} onChange={onChange} className="input" />
        </div>
        <div className="form-group">
          <label className="form-label">Color</label>
          <div style={{ display:'flex', gap:8 }}>
            <input name="color" value={form.color} onChange={onChange} className="input" style={{ flex:1 }} />
            <input type="color" name="colorHex" value={form.colorHex} onChange={onChange}
              style={{ width:42, height:42, borderRadius:10, border:'1px solid var(--border)', background:'var(--bg3)', cursor:'pointer', padding:3 }} />
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Style</label>
          <select name="style" value={form.style} onChange={onChange} className="input">
            {STYLES.map(s => <option key={s} value={s} style={{ background:'#1e2026' }}>{s}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">Season</label>
          <select name="season" value={form.season} onChange={onChange} className="input">
            {SEASONS.map(s => <option key={s} value={s} style={{ background:'#1e2026' }}>{s}</option>)}
          </select>
        </div>
        <div style={{ display:'flex', gap:10, marginTop:4 }}>
          <button onClick={onClose} className="btn btn-outline" style={{ flex:1, justifyContent:'center' }}>Cancel</button>
          <button onClick={save} disabled={saving} className="btn btn-primary" style={{ flex:1, justifyContent:'center' }}>
            {saving ? <div className="spinner" style={{ width:16, height:16 }} /> : <><RiCheckLine /> Save</>}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Wardrobe() {
  const [items,     setItems]     = useState([]);
  const [filters,   setFilters]   = useState({ category:'all', style:'all', search:'' });
  const [editItem,  setEditItem]  = useState(null);
  const [deletingId,setDeletingId]= useState(null);

  const load = useCallback(() => {
    setItems(clothesStore.getAll(filters));
  }, [filters]);

  useEffect(() => { load(); }, [load]);

  const handleDelete = id => {
    if (!window.confirm('Remove this item from your wardrobe?')) return;
    setDeletingId(id);
    clothesStore.delete(id);
    setItems(prev => prev.filter(i => i.id !== id));
    toast.success('Item removed');
    setDeletingId(null);
  };

  const handleSave = (id, updates) => {
    clothesStore.update(id, updates);
    setItems(prev => prev.map(i => i.id === id ? { ...i, ...updates } : i));
    toast.success('Item updated');
  };

  const CATS = ['all','topwear','bottomwear','footwear','outerwear'];

  return (
    <div className="page">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
        <div>
          <h1 className="page-title">My Wardrobe</h1>
          <p className="page-sub" style={{ marginBottom:0 }}>{items.length} item{items.length !== 1 ? 's' : ''}</p>
        </div>
        <Link to="/upload" className="btn btn-primary" style={{ flexShrink:0 }}>
          <RiUploadCloud2Line /> Add
        </Link>
      </div>

      {/* Search */}
      <div style={{ position:'relative', margin:'20px 0 12px' }}>
        <RiSearchLine style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text3)', fontSize:17 }} />
        <input value={filters.search} onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
          className="input" placeholder="Search by name..." style={{ paddingLeft:38 }} />
      </div>

      {/* Category filters */}
      <div style={{ display:'flex', gap:7, flexWrap:'wrap', marginBottom:20 }}>
        {CATS.map(cat => (
          <button key={cat} onClick={() => setFilters(f => ({ ...f, category: cat }))}
            style={{
              padding:'5px 14px', borderRadius:20, fontSize:13, fontWeight:500,
              background: filters.category === cat ? 'var(--brand)' : 'rgba(255,255,255,0.05)',
              color:       filters.category === cat ? '#fff' : 'var(--text3)',
              border: `1px solid ${filters.category === cat ? 'var(--brand)' : 'var(--border)'}`,
              cursor:'pointer', textTransform:'capitalize', transition:'all 0.15s',
            }}>
            {cat === 'all' ? 'All Items' : cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      {items.length === 0 ? (
        <div className="card" style={{ textAlign:'center', padding:'60px 20px' }}>
          <div style={{ fontSize:52, marginBottom:14 }}>🧺</div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:20, color:'var(--text)', marginBottom:8 }}>
            {filters.category !== 'all' || filters.search ? 'No items match your filters' : 'Your wardrobe is empty'}
          </div>
          <p style={{ color:'var(--text3)', fontSize:14, marginBottom:20 }}>
            {filters.category !== 'all' || filters.search ? 'Try changing filters' : 'Upload your first clothing item'}
          </p>
          <Link to="/upload" className="btn btn-primary" style={{ margin:'0 auto' }}>
            <RiUploadCloud2Line /> Upload Clothes
          </Link>
        </div>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(150px,1fr))', gap:12 }}>
          {items.map(item => {
            const cs = CAT_STYLE[item.category] || CAT_STYLE.accessory;
            return (
              <div key={item.id} style={{ borderRadius:16, overflow:'hidden', border:'1px solid var(--border)', background:'var(--bg3)', position:'relative' }}
                className="group-item">
                {/* Image */}
                <div style={{ aspectRatio:'3/4', overflow:'hidden', background:'var(--bg4)', position:'relative' }}>
                  <img src={item.imageData} alt={item.name || item.type}
                    style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                  {/* Hover actions */}
                  <div style={{ position:'absolute', top:8, right:8, display:'flex', gap:5, opacity:0, transition:'opacity 0.2s' }} className="item-actions">
                    <button onClick={() => setEditItem(item)}
                      style={{ width:30, height:30, borderRadius:'50%', background:'rgba(0,0,0,0.7)', backdropFilter:'blur(4px)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15, border:'none', cursor:'pointer' }}>
                      <RiEditLine />
                    </button>
                    <button onClick={() => handleDelete(item.id)}
                      style={{ width:30, height:30, borderRadius:'50%', background:'rgba(0,0,0,0.7)', backdropFilter:'blur(4px)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15, border:'none', cursor:'pointer' }}>
                      {deletingId === item.id ? <div className="spinner" style={{ width:12, height:12 }} /> : <RiDeleteBinLine />}
                    </button>
                  </div>
                </div>
                {/* Info */}
                <div style={{ padding:'8px 10px 10px' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:4, marginBottom:4 }}>
                    <div style={{ fontSize:12, fontWeight:500, color:'var(--text)', textTransform:'capitalize', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', flex:1 }}>{item.name || item.type}</div>
                    <div style={{ width:12, height:12, borderRadius:'50%', background: item.colorHex || '#000', border:'1px solid rgba(255,255,255,0.15)', flexShrink:0, marginTop:2 }} />
                  </div>
                  <div style={{ fontSize:11, color:'var(--text3)', textTransform:'capitalize', marginBottom:5 }}>{item.color} · {item.style}</div>
                  <span className="badge" style={{ background: cs.bg, color: cs.color, fontSize:10 }}>{item.category}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {editItem && <EditModal item={editItem} onClose={() => setEditItem(null)} onSave={handleSave} />}

      <style>{`
        .group-item:hover .item-actions { opacity: 1 !important; }
        .group-item { transition: transform 0.2s; }
        .group-item:hover { transform: translateY(-2px); }
      `}</style>
    </div>
  );
}
