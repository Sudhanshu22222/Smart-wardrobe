import React, { createContext, useContext, useState, useEffect } from 'react';
import { authStore } from '../utils/store';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem('oa_session');
    if (saved) {
      const u = authStore.getUser();
      if (u) setUser(u);
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    const u = authStore.login(email, password);
    localStorage.setItem('oa_session', '1');
    setUser(u);
    return u;
  };

  const register = (name, email, password) => {
    const u = authStore.register(name, email, password);
    localStorage.setItem('oa_session', '1');
    setUser(u);
    return u;
  };

  const logout = () => {
    localStorage.removeItem('oa_session');
    setUser(null);
  };

  const updateUser = (updates) => {
    const u = authStore.updateUser(updates);
    setUser(u);
    return u;
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
